This folder contains the grammar files matching the antlr v4 grammar.

It is a copy from antlrv4/grammarsv4/antlrv4

Build using the ant build script.