package org.github.antlr4ide.editor.outliner;

import org.eclipse.jface.text.*;
import org.eclipse.jface.text.rules.ITokenScanner;
import org.eclipse.jface.viewers.*;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.ui.texteditor.IDocumentProvider;
import org.eclipse.ui.texteditor.ITextEditor;
import org.eclipse.ui.views.contentoutline.ContentOutlinePage;
import org.github.antlr4ide.editor.ANTLRv4Configuration;
import org.github.antlr4ide.editor.ANTLRv4Editor;
import org.github.antlr4ide.editor.AntlrScanner;

/**
 * This sample class demonstrates how to plug-in a new workbench view. The view
 * shows data obtained from the model. The sample creates a dummy model on the
 * fly, but a real implementation would connect to the model available either in
 * this or another plug-in (e.g. the workspace). The view is connected to the
 * model using a content provider.
 * <p>
 * The view uses a label provider to define how model objects should be
 * presented in the view. Each view can present the same model objects using
 * different labels and icons, if needed. Alternatively, a single label provider
 * can be shared between views in order to ensure that objects of the same type
 * are presented in the same way everywhere.
 * <p>
 * see
 * http://alvinalexander.com/java/jwarehouse/eclipse/org.eclipse.ui.examples.javaeditor/Eclipse-Java-Editor-Example/org/eclipse/ui/examples/javaeditor/JavaContentOutlinePage.java.shtml
 * see
 * http://www.eclipse.org/articles/Article-TreeViewer/TreeViewerArticle.htm?PHPSESSID=4d48764999a9cb66a7fd58a954ef2131
 */

public class AntlrDocOutlineView extends ContentOutlinePage {
	private boolean DEBUG = true; // false; // debug outline view

	/**
	 * The ID of the view as specified by the extension.
	 */
	public static final String ID = "org.github.antlr4ide.editor.outliner.AntlrDocOutlineView";

	/**
	 * A segment element.
	 */
	protected static class Segment {
		public String name;
		public Position position;

		public Segment(String name, Position position) {
			this.name = name;
			this.position = position;
		}

		public String toString() {
			return name;
		}
	}

	protected Object fInput;
	protected IDocumentProvider fDocumentProvider;
	protected ITextEditor fTextEditor;
	protected AntlrScanner fScanner;

	/**
	 * Creates a content outline page using the given provider and the given editor.
	 * 
	 * @param provider
	 *            the document provider
	 * @param editor
	 *            the editor
	 */
	public AntlrDocOutlineView(IDocumentProvider provider, ITextEditor editor) {
		super();
		if (DEBUG)
			System.out.println(">>> AntlrDocOutlineView (" + provider.getClass() + ", " + editor.getClass() + ")");
		fDocumentProvider = provider;
		fTextEditor = editor;

		// get the configured scanner for the editor
		fScanner = ((ANTLRv4Configuration) ((ANTLRv4Editor) editor).getEditorConfiguration()).getANTLRv4Scanner();
		if (DEBUG)
			System.out.println(">>> AntlrDocOutlineView scanner " + fScanner.getClass() + " ");

	}

	/*
	 * (non-Javadoc) Method declared on ContentOutlinePage
	 */
	@Override
	public void createControl(Composite parent) {
		if (DEBUG)
			System.out.println(">>> AntlrDocOutlineView.createControl (" + parent.getClass() + ")");

		super.createControl(parent);

		TreeViewer viewer = getTreeViewer();
		viewer.setContentProvider(new AntlrDocOutlineContentProvider(fDocumentProvider, fScanner));
		viewer.setLabelProvider(new LabelProvider());
		viewer.addSelectionChangedListener(this);

		if (fInput != null)
			viewer.setInput(fInput);
	}

	/*
	 * (non-Javadoc) Method declared on ContentOutlinePage
	 */
	@Override
	public void selectionChanged(SelectionChangedEvent event) {
		if (DEBUG)
			System.out.println(">>> AntlrDocOutlineView.selectionChanged (" + event.getClass() + ")");

		super.selectionChanged(event);

		IStructuredSelection selection = (IStructuredSelection) event.getSelection();

		if (DEBUG)
			System.out.println(">>> AntlrDocOutlineView.selectionChanged selection "
					+ selection.getFirstElement().getClass() + "");

		if (selection.isEmpty())
			fTextEditor.resetHighlightRange();
		else {
			Position pos = null;
			if (selection.getFirstElement() instanceof String) {
				pos = fScanner.getParserRules().get(selection.getFirstElement());
				if (pos == null)
					pos = fScanner.getLexerRules().get(selection.getFirstElement());
			}

			if (pos != null) {
				try {
					fTextEditor.setHighlightRange(pos.getOffset(), pos.getLength(), true);
				} catch (IllegalArgumentException x) {
					fTextEditor.resetHighlightRange();
				}
			}
		}
	}

	/**
	 * Sets the input of the outline page
	 * 
	 * @param input
	 *            the input of this outline page
	 */
	public void setInput(Object input) {
		// System.out.println(">>> OutlineView.setInput
		// ("+(input==null?"null":input.getClass())+")");
		fInput = input;
		update();
	}

	/**
	 * Updates the outline page.
	 */
	public void update() {
		// System.out.println(">>> OutlineView.update");
		TreeViewer viewer = getTreeViewer();

		if (viewer != null) {
			Control control = viewer.getControl();
			if (control != null && !control.isDisposed()) {
				control.setRedraw(false);
				viewer.setInput(fInput);
				viewer.expandAll();
				control.setRedraw(true);
			}
		}
	}

}