package org.github.antlr4ide.editor.outliner;

import org.eclipse.jface.text.BadPositionCategoryException;
import org.eclipse.jface.text.DefaultPositionUpdater;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IPositionUpdater;
import org.eclipse.jface.text.rules.ITokenScanner;
import org.eclipse.jface.viewers.ITreeContentProvider;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.ui.texteditor.IDocumentProvider;
import org.github.antlr4ide.editor.AntlrScanner;

/**
 * Divides the editor's document into ten segments and provides elements for them.
 */
public class AntlrDocOutlineContentProvider implements ITreeContentProvider {

	//TODO: If everything is rescanned by the partition scanner, and parse is using the updated partition scans, then there is not need for SEGMETS, fPositionUpdater
	protected final static String SEGMENTS= "__dflt_segments";
	protected IPositionUpdater fPositionUpdater= new DefaultPositionUpdater(SEGMENTS);
	protected AntlrScanner fScanner;
	private IDocumentProvider fDocumentProvider;
	private boolean DEBUG=true; //false;
	
	public AntlrDocOutlineContentProvider(IDocumentProvider fDocumentProvider, ITokenScanner fScanner) {
		this.fDocumentProvider = fDocumentProvider;
		this.fScanner=(AntlrScanner) fScanner;
	}



	protected void parse(IDocument document) {	
		if(DEBUG)
			System.out.println(">>> AntlrDocOutlineContentProvider.parse ("+document.getClass()+")");
		// set content for outline page.
//		fTree=info.asTree();
	}

	/*
	 * @see IContentProvider#inputChanged(Viewer, Object, Object)
	 */
	public void inputChangedXX(Viewer viewer, Object oldInput, Object newInput) {
//		if(DEBUG)
			System.out.println(">>> AntlrDocOutlineOutlineContentProvider.inputChanged ("
	     +(viewer==null?"null":viewer.getClass())
	+", "+(oldInput==null?"null":oldInput.getClass())
	+", "+(newInput==null?"null":newInput.getClass())+")");

		
		if (oldInput != null) {
			IDocument document= fDocumentProvider.getDocument(oldInput);
			if (document != null) {
				try {
					document.removePositionCategory(SEGMENTS);
				} catch (BadPositionCategoryException ex) {
					ex.printStackTrace();
				}
				document.removePositionUpdater(fPositionUpdater);
			}
		}

//		fContent.clear();

		if (newInput != null) {
			IDocument document= fDocumentProvider.getDocument(newInput);
			if (document != null) {
				document.addPositionCategory(SEGMENTS);
				document.addPositionUpdater(fPositionUpdater);

				// invoke overriden method to get actual content
				parse(document);
			}
		}
	}

	/*
	 * @see IContentProvider#dispose
	 */
	public void dispose() {
		if(DEBUG)
			System.out.println(">>> AntlrDocOutlineOutlineContentProvider.dispose");
//		if (fContent != null) {
//			fContent.clear();
//			fContent= null;
//		}
	}

	/*
	 * @see IContentProvider#isDeleted(Object)
	 */
	public boolean isDeleted(Object element) {
		if(DEBUG)
			System.out.println(">>> AntlrDocOutlineOutlineContentProvider.isDeleted ("+(element==null?"null":element.getClass())+")");
		return false;
	}

	/*
	 * @see IStructuredContentProvider#getElements(Object)
	 */
	public Object[] getElements(Object element) {
		if(DEBUG)
			System.out.println(">>> AntlrDocOutlineOutlineContentProvider.getElements ("+(element==null?"null":element.getClass())+")");
//		Object ret[]=new Object[1];
//		if (element instanceof OakTree<?>)
//		   ret[0]=((OakTree<?>)element).getData();
//		else // get the root leaves
//		   ret=fTree.getChildren().toArray();
//		
//		return ret;
		Object ret[]=new Object[2];
		ret[0]=new OutlineRootElement("Parser Rules",0);
		ret[1]=new OutlineRootElement("Lexer Rules",1);
		return ret ;
	}

	/*
	 * @see ITreeContentProvider#hasChildren(Object)
	 */
	public boolean hasChildren(Object element) {
		if(DEBUG)
			System.out.println(">>> AntlrDocOutlineOutlineContentProvider.hasChildren ("+(element==null?"null":element.getClass())+")");
		if (element instanceof OutlineRootElement) {
			Integer type= ((OutlineRootElement)element).getType();
			if(type==0) return fScanner.getParserRules().isEmpty()==false;
			if(type==1) return fScanner.getLexerRules().isEmpty()==false;
		}
//		return ((OakTree<?>)element).hasChildren();
		return false;
	}

	/*
	 * @see ITreeContentProvider#getParent(Object)
	 */
	public Object getParent(Object element) {
		if(DEBUG)
			System.out.println(">>> AntlrDocOutlineOutlineContentProvider.getParent ("+(element==null?"null":element.getClass())+")");
//		if (element instanceof OakTree<?>)
//			return ((OakTree<?>)element).getParent();
		return null;
	}

	/*
	 * @see ITreeContentProvider#getChildren(Object)
	 */
	public Object[] getChildren(Object element) {
		if(DEBUG)
			System.out.println(">>> AntlrDocOutlineOutlineContentProvider.getChildren "+(element==null?"null":element.getClass())+")");
//		if (element instanceof OakTree)
//			return ((OakTree<?>)element).getChildren().toArray();
		
		if (element instanceof OutlineRootElement) {
			Integer type= ((OutlineRootElement)element).getType();
			if(type==0) return fScanner.getParserRules().keySet().toArray();
			if(type==1) return fScanner.getLexerRules().keySet().toArray();
		}
		
		return new Object[0];
	}
	
	public interface IOutlineRootElement {
		public String toString();
	}
	public class OutlineRootElement implements IOutlineRootElement {
		private String s;
		private Integer type;
		public OutlineRootElement(String s, int type) {this.s=s; this.type=type;}
		public String toString() {return s;}
		public Integer getType() { return type; }
	}
}

