package org.github.antlr4ide.editor;

import java.util.List;
import java.util.Map;

import org.antlr.parser.antlr4.ANTLRv4Lexer;
import org.antlr.parser.antlr4.ANTLRv4Parser;
import org.antlr.parser.antlr4.ANTLRv4ParserBaseVisitor;
import org.antlr.v4.runtime.ANTLRInputStream;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.Token;
import org.antlr.v4.runtime.tree.ParseTree;
import org.eclipse.jface.text.Position;

public class LexerHelper {
	private Map<String, Position> parserRules;
	private Map<String, Position> lexerRules;

	public LexerHelper(Map<String, Position> parserRules, Map<String, Position> lexerRules) {
		this.parserRules = parserRules;
		this.lexerRules = lexerRules;
	}

	public List<? extends Token> scanString(String s) {
		long pot[] = new long[4];

		pot[0] = System.currentTimeMillis();

		ANTLRInputStream antlrInputStream = new ANTLRInputStream(s);
		ANTLRv4Lexer lexer = new ANTLRv4Lexer(antlrInputStream);
		pot[1] = System.currentTimeMillis();
		CommonTokenStream tokens = new CommonTokenStream(lexer);
		ANTLRv4Parser parser = new ANTLRv4Parser(tokens);
		parser.setBuildParseTree(true);
		ParseTree tree = parser.grammarSpec();
		pot[2] = System.currentTimeMillis();
		ANTLRv4Visitor visitor = new ANTLRv4Visitor();
		visitor.visit(tree);
		pot[3] = System.currentTimeMillis();

		System.out.println("Elapsed time " + (pot[3] - pot[0]));
		System.out.println("   lexer     " + (pot[1] - pot[0]));
		System.out.println("   parser    " + (pot[2] - pot[1]));
		System.out.println("   visitor   " + (pot[3] - pot[2]));

		return tokens.getTokens();
	}

	public class ANTLRv4Visitor extends ANTLRv4ParserBaseVisitor<Void> {

		@Override
		public Void visitGrammarSpec(ANTLRv4Parser.GrammarSpecContext ctx) {
			/*
			 * grammarSpec : DOC_COMMENT* grammarType identifier SEMI prequelConstruct*
			 * rules modeSpec* EOF
			 */

			String id = ctx.identifier().getText(); // name of imported grammar
			System.out.println(">>> ANTLRv4Visitor visitGrammarSpec. Gramamr name >" + id + "<");

			return visitChildren(ctx); // continue the visit
		}

		@Override
		public Void visitDelegateGrammar(ANTLRv4Parser.DelegateGrammarContext ctx) {
			/*
			 * delegateGrammars : IMPORT delegateGrammar (COMMA delegateGrammar)* SEMI
			 * delegateGrammar : identifier ASSIGN identifier | identifier
			 */

			String id = ctx.identifier(0).getText(); // name of imported grammar
			String id2;
			if (ctx.identifier().size() > 1)
				id2 = ctx.identifier(1).getText();

			System.out.println(">>> ANTLRv4Visitor visitDelegateGrammar. Import name >" + id + "<");

			return visitChildren(ctx); // continue the visit
		}

		@Override
		public Void visitParserRuleSpec(ANTLRv4Parser.ParserRuleSpecContext ctx) {
			// Track this for outline and cross references
			/*
			 * parserRuleSpec : DOC_COMMENT* ruleModifiers? RULE_REF argActionBlock?
			 * ruleReturns? throwsSpec? localsSpec? rulePrequel* COLON ruleBlock SEMI
			 * exceptionGroup
			 */

			System.out.println(
					">>> ANTLRv4Visitor visitParserRuleSpec. Defining parser rule >" + ctx.RULE_REF().getText() + "<");

			int a=ctx.start.getStartIndex(); // ctx.RULE_REF().getSymbol().getStartIndex()
			int b=ctx.stop.getStopIndex();  // ctx.RULE_REF().getSymbol().getStopIndex()

			Position position = new Position(a,b-a); // mark the whole rule
			
			emitParserRule(ctx.RULE_REF().getText(), position);

			return visitChildren(ctx); // continue the visit
		}

		@Override
		public Void visitLexerRuleSpec(ANTLRv4Parser.LexerRuleSpecContext ctx) {
			// Track this for outline and cross references
			/*
			 * parserRuleSpec : DOC_COMMENT* ruleModifiers? RULE_REF argActionBlock?
			 * ruleReturns? throwsSpec? localsSpec? rulePrequel* COLON ruleBlock SEMI
			 * exceptionGroup
			 */

			System.out.println(
					">>> ANTLRv4Visitor visitLexerRuleSpec. Defining lexer rule >" + ctx.TOKEN_REF().getText() + "<");
			
			int a=ctx.start.getStartIndex(); // ctx.TOKEN_REF().getSymbol().getStartIndex()
			int b=ctx.stop.getStopIndex();  // ctx.TOKEN_REF().getSymbol().getStopIndex()

			Position position = new Position(a,b-a); // mark the whole rule

			emitLexerRule(ctx.TOKEN_REF().getText(), position);

			return visitChildren(ctx); // continue the visit
		}

	}

	private void emitParserRule(String text, Position position) {
		parserRules.put(text, position);
	}
	private void emitLexerRule(String text, Position position) {
		lexerRules.put(text, position);
	}

}
